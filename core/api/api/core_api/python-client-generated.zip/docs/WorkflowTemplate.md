# WorkflowTemplate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **str** |  | [optional] 
**uid** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**version** | **int** |  | [optional] 
**manifest** | **str** |  | [optional] 
**is_latest** | **bool** |  | [optional] 
**is_archived** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


