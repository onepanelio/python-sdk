# File

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**extension** | **str** |  | [optional] 
**size** | **str** |  | [optional] 
**content_type** | **str** |  | [optional] 
**last_modified** | **str** |  | [optional] 
**directory** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


